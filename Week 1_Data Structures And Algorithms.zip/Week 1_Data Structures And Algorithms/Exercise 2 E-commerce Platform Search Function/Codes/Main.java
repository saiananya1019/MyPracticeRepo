import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(101, "Laptop", "Electronics"),
            new Product(102, "Shirt", "Clothing"),
            new Product(103, "Book", "Education"),
            new Product(104, "Phone", "Electronics"),
            new Product(105, "Shoes", "Footwear")
        };

        System.out.println("Linear Search:");
        Product foundLinear = SearchAlgorithms.linearSearch(products, 103);
        System.out.println(foundLinear != null ? foundLinear : "Product not found");

        // Sort array for binary search
        Arrays.sort(products, Comparator.comparingInt(p -> p.productId));

        System.out.println("Binary Search:");
        Product foundBinary = SearchAlgorithms.binarySearch(products, 103);
        System.out.println(foundBinary != null ? foundBinary : "Product not found");
    }
}