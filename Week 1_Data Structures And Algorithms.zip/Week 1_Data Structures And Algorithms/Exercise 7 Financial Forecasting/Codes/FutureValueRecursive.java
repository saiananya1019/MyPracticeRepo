public class FutureValueRecursive {
    public static double futureValueRecursive(double PV, double r, int n) {
        if (n == 0) {
            return PV;
        }
        return (1 + r) * futureValueRecursive(PV, r, n - 1);
    }

    public static void main(String[] args) {
        double PV = 1000;
        double r = 0.05;
        int n = 3;

        double result = futureValueRecursive(PV, r, n);
        System.out.printf("Future Value (Recursive): %.2f\n", result);
    }
}
