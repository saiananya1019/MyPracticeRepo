-- Drop tables if they exist
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Loans';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE Customers';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

-- Create Customers table
CREATE TABLE Customers (
  CustomerID NUMBER PRIMARY KEY,
  CustomerName VARCHAR2(100),
  Age NUMBER,
  Balance NUMBER,
  IsVIP VARCHAR2(10)
);

-- Create Loans table
CREATE TABLE Loans (
  LoanID NUMBER PRIMARY KEY,
  CustomerID NUMBER,
  InterestRate NUMBER,
  DueDate DATE,
  FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert sample data
INSERT INTO Customers VALUES (1, 'Alice', 65, 12000, 'FALSE');
INSERT INTO Customers VALUES (2, 'Bob', 45, 8000, 'FALSE');

INSERT INTO Loans VALUES (101, 1, 10.5, SYSDATE + 20);
INSERT INTO Loans VALUES (102, 2, 11.0, SYSDATE + 45);

COMMIT;
-- Enable output
SET SERVEROUTPUT ON;

-- Scenario 1: Apply 1% interest discount for age > 60
BEGIN
  FOR cust IN (SELECT CustomerID, Age FROM Customers) LOOP
    IF cust.Age > 60 THEN
      UPDATE Loans
      SET InterestRate = InterestRate - 1
      WHERE CustomerID = cust.CustomerID;
    END IF;
  END LOOP;
  COMMIT;
END;
/

-- Scenario 2: Set IsVIP to TRUE for balance > 10000
BEGIN
  FOR cust IN (SELECT CustomerID, Balance FROM Customers) LOOP
    IF cust.Balance > 10000 THEN
      UPDATE Customers
      SET IsVIP = 'TRUE'
      WHERE CustomerID = cust.CustomerID;
    END IF;
  END LOOP;
  COMMIT;
END;
/

-- Scenario 3: Loan reminders due in next 30 days
DECLARE
  v_name VARCHAR2(100);
  v_due  DATE;
BEGIN
  FOR loan_row IN (
    SELECT c.CustomerName AS name, l.DueDate AS due
    FROM Customers c
    JOIN Loans l ON c.CustomerID = l.CustomerID
    WHERE l.DueDate <= SYSDATE + 30
  ) LOOP
    v_name := loan_row.name;
    v_due  := loan_row.due;

    DBMS_OUTPUT.PUT_LINE('Reminder: Loan due for ' || v_name ||
                         ' on ' || TO_CHAR(v_due, 'DD-MON-YYYY'));
  END LOOP;
END;
/

