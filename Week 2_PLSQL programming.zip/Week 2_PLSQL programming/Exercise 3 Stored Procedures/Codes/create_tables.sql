BEGIN EXECUTE IMMEDIATE 'DROP TABLE Accounts'; EXCEPTION WHEN OTHERS THEN NULL; END;
BEGIN EXECUTE IMMEDIATE 'DROP TABLE Employees'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- Create Accounts table
CREATE TABLE Accounts (
    AccountID NUMBER PRIMARY KEY,
    CustomerName VARCHAR2(100),
    Balance NUMBER,
    AccountType VARCHAR2(20)
);
/

-- Create Employees table
CREATE TABLE Employees (
    EmployeeID NUMBER PRIMARY KEY,
    Name VARCHAR2(100),
    Department VARCHAR2(50),
    Salary NUMBER
);
/

-- Insert sample data into Accounts
INSERT INTO Accounts VALUES (1, 'Alice', 5000, 'savings');
INSERT INTO Accounts VALUES (2, 'Bob', 3000, 'checking');
INSERT INTO Accounts VALUES (3, 'Charlie', 7000, 'savings');
INSERT INTO Accounts VALUES (4, 'David', 2000, 'savings');
/

-- Insert sample data into Employees
INSERT INTO Employees VALUES (101, 'John', 'HR', 40000);
INSERT INTO Employees VALUES (102, 'Jane', 'IT', 50000);
INSERT INTO Employees VALUES (103, 'Mike', 'IT', 55000);
/