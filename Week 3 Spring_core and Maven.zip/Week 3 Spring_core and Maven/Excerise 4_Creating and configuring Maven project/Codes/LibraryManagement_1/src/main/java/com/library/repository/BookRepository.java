package com.library.repository;

public class BookRepository {
    public String getBookDetails() {
        return "📘 Title: Effective Java\n👤 Author: Sai Ananya J\n📗 ISBN: 978-0134685991";
    }
}