package com.library.service;

import com.library.repository.BookRepository;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void displayBook() {
        if (bookRepository != null) {
            System.out.println("📚 Library System Initialized Successfully!");
            System.out.println("Book Details:\n" + bookRepository.getBookDetails());
        } else {
            System.out.println("❌ BookRepository not injected.");
        }
    }
}