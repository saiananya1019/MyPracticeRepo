package com.library.service;

import com.library.repository.BookRepository;

public class BookService {

    private BookRepository bookRepository;

    // Setter for Dependency Injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void displayBook() {
        if (bookRepository != null) {
            System.out.println("Dependency Injection was successful!");
            System.out.println("Book: " + bookRepository.getBook());
        } else {
            System.out.println("Dependency Injection failed: BookRepository is null.");
        }
    }
}