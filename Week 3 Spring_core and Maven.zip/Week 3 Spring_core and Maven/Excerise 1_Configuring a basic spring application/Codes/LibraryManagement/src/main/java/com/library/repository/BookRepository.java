package com.library.repository;

public class BookRepository {
    public String getBook() {
        return "Clean Code by Robert C. Martin";
    }
}