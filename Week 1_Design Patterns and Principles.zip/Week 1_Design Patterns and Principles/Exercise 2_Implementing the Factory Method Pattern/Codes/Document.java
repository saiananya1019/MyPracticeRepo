package Codes;

public interface Document {
    void open();
}
